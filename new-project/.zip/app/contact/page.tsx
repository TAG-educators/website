import type { Metadata } from 'next';
import { Mail, MessageCircle, Phone, Ship } from 'lucide-react';
import { PageLayout } from '@/components/sections/page-layout';
import { PageHeader } from '@/components/sections/page-header';
import { ContactForm } from '@/components/sections/contact-form';
import { AnimatedSection } from '@/components/sections/animated-section';
import { siteConfig } from '@/lib/site-config';

export const metadata: Metadata = {
  title: 'Contact',
  description:
    'Get in touch with TAG Educators. Message us on WhatsApp, send us an email, or fill out our contact form. We will help you find the right tutor for your subject.',
  alternates: { canonical: '/contact' },
};

export default function ContactPage() {
  return (
    <PageLayout>
      <PageHeader
        eyebrow="Get In Touch"
        title="Contact Us"
        description="Message us your subject and level on WhatsApp, or fill out the form below. We will help you find the right tutor for your Cambridge O Level, A Level or IGCSE subject."
      />

      <section className="bg-white py-20 md:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-12 lg:grid-cols-3">
            {/* Contact info */}
            <AnimatedSection animation="fade-up" className="lg:col-span-1">
              <h2 className="font-display text-2xl font-bold text-foreground">Reach Us Directly</h2>
              <p className="mt-4 text-base text-muted-foreground">
                Prefer to message us directly? We are one tap away.
              </p>

              <div className="mt-8 space-y-4">
                <a
                  href={siteConfig.whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group flex items-start gap-4 rounded-2xl border border-border bg-white p-5 shadow-sm transition-all hover:border-ocean hover:shadow-premium"
                >
                  <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-ocean/10 text-ocean transition-colors group-hover:bg-ocean group-hover:text-white">
                    <MessageCircle className="h-6 w-6" />
                  </div>
                  <div>
                    <div className="font-display text-base font-bold text-foreground">WhatsApp</div>
                    <div className="mt-0.5 text-sm text-muted-foreground">
                      {siteConfig.whatsappDisplay}
                    </div>
                  </div>
                </a>

                <a
                  href={`mailto:${siteConfig.email}`}
                  className="group flex items-start gap-4 rounded-2xl border border-border bg-white p-5 shadow-sm transition-all hover:border-ocean hover:shadow-premium"
                >
                  <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-ocean/10 text-ocean transition-colors group-hover:bg-ocean group-hover:text-white">
                    <Mail className="h-6 w-6" />
                  </div>
                  <div>
                    <div className="font-display text-base font-bold text-foreground">Email</div>
                    <div className="mt-0.5 text-sm text-muted-foreground">{siteConfig.email}</div>
                  </div>
                </a>

                <div className="flex items-start gap-4 rounded-2xl border border-border bg-white p-5 shadow-sm">
                  <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-ocean/10 text-ocean">
                    <Phone className="h-6 w-6" />
                  </div>
                  <div>
                    <div className="font-display text-base font-bold text-foreground">Sessions</div>
                    <div className="mt-0.5 text-sm text-muted-foreground">
                      Live online, worldwide
                    </div>
                  </div>
                </div>

                <div className="flex items-start gap-4 rounded-2xl border border-ocean/20 bg-ocean/5 p-5">
                  <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-ocean text-white">
                    <Ship className="h-6 w-6" />
                  </div>
                  <div>
                    <div className="font-display text-base font-bold text-foreground">
                      {siteConfig.fullName}
                    </div>
                    <div className="mt-0.5 text-sm text-muted-foreground">
                      {siteConfig.tagline}
                    </div>
                  </div>
                </div>
              </div>
            </AnimatedSection>

            {/* Contact form */}
            <AnimatedSection animation="fade-up" delay={0.15} className="lg:col-span-2">
              <ContactForm />
            </AnimatedSection>
          </div>
        </div>
      </section>
    </PageLayout>
  );
}
