import type { Metadata } from 'next';
import { PageLayout } from '@/components/sections/page-layout';
import { SubjectCard } from '@/components/sections/subject-card';
import { FloatingSymbols } from '@/components/sections/floating-symbols';
import { courses } from '@/lib/courses';

export const metadata: Metadata = {
  title: 'Courses',
  description:
    'Browse all TAG Educators courses   Physics, Chemistry, Mathematics, Biology, Computer Science, Business Studies, Economics and Accounts. Cambridge O Level, A Level and IGCSE.',
  alternates: { canonical: '/courses' },
};

export default function CoursesPage() {
  return (
    <PageLayout>
      <section className="relative overflow-hidden bg-ocean-deeper pt-32 pb-20 md:pt-40 md:pb-28" data-header-theme="dark">
        <div className="absolute inset-0 bg-grid-pattern opacity-[0.04]" />
        <div className="absolute left-1/4 top-1/4 h-72 w-72 rounded-full bg-ocean/20 blur-[120px]" />
        <div className="absolute right-1/4 bottom-0 h-72 w-72 rounded-full bg-ocean-light/10 blur-[100px]" />
        <FloatingSymbols />

        <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <p className="text-[0.78rem] font-semibold uppercase tracking-[0.16em]" style={{ color: '#b472cc' }}>Our Courses</p>
            <h1 className="mt-4 font-display text-4xl font-bold tracking-tight text-white sm:text-5xl lg:text-6xl text-balance">
              Every subject has its own tutor   and its own page
            </h1>
            <p className="mt-5 text-lg leading-relaxed text-white/70 text-pretty">
              Pick a subject below to meet the tutor, see current batches, and register. All courses cover Cambridge O Level, A Level and IGCSE.
            </p>
          </div>

          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {courses.map((course) => (
              <SubjectCard key={course.slug} course={course} />
            ))}
          </div>
        </div>
      </section>
    </PageLayout>
  );
}
