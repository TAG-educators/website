import type { Metadata } from 'next';
import { PageLayout } from '@/components/sections/page-layout';
import { PageHeader } from '@/components/sections/page-header';
import { FacultyCard } from '@/components/sections/faculty-card';
import { AnimatedSection } from '@/components/sections/animated-section';
import { FloatingSymbols } from '@/components/sections/floating-symbols';
import { faculty } from '@/lib/faculty';

export const metadata: Metadata = {
  title: 'Faculty',
  description:
    'Meet TAG Educators faculty   specialist tutors who have sat these exact Cambridge exams and currently teach at O Level and A Level schools. Two are formally Cambridge certified.',
  alternates: { canonical: '/faculty' },
};

export default function FacultyPage() {
  return (
    <PageLayout>
      <PageHeader
        eyebrow="Our Faculty"
        title="Meet Your Educators"
        description="Every TAG tutor has sat these exact Cambridge papers and currently teaches at an O Level school or A Level college. Not a generalist matched to a subject list   a subject specialist with real exam experience."
        backgroundContent={<FloatingSymbols />}
        bottomContent={
          <div className="relative z-10 mx-auto mt-12 max-w-7xl px-4 pb-20 sm:px-6 md:pb-24 lg:px-8">
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {faculty.map((member) => (
                <FacultyCard key={member.slug} member={member} />
              ))}
            </div>

            <AnimatedSection
              animation="fade-up"
              delay={0.2}
              className="mt-16 rounded-2xl border border-border bg-white p-8 md:p-12"
            >
              <h2 className="font-display text-2xl font-bold text-foreground">
                Real Classroom Experience, Real Exam Experience
              </h2>
              <p className="mt-4 max-w-3xl text-base leading-relaxed text-muted-foreground">
                Every TAG tutor has sat these exact Cambridge papers and currently teaches at an
                O Level school or A Level college. Two of our faculty are also formally Cambridge
                certified   bringing insider knowledge of exact exam traps and mark-scheme expertise
                to every micro-cohort session.
              </p>
            </AnimatedSection>
          </div>
        }
      />

    </PageLayout>
  );
}
