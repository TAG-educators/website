'use client';

import { useEffect, useRef, useCallback } from 'react';

type SymbolData = {
  id: number;
  char: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  baseVx: number;
  baseVy: number;
  size: number;
  opacity: number;
  rotation: number;
  rotationSpeed: number;
  color: string;
  el: HTMLSpanElement | null;
};

// Symbols grouped by subject
const subjectSymbols: Record<string, string[]> = {
  physics: [
    'F=ma', 'v=λf', 'P=IV', 'Q=mcΔT', 'e=mc²', 'E=½mv²', 'λ', 'μ', 'θ',
    'ω', '∇', '∂', 'Hz', 'W', 'J', 'N', 'Pa', 'V', 'A', 'Ω',
    'v=d/t', 'a=Δv/Δt', 'ρ=m/V', 'F=Gm₁m₂/r²',
  ],
  chemistry: [
    'H₂O', 'CO₂', 'O₂', 'N₂', 'NaCl', 'pH', 'mol', 'C₆H₁₂O₆',
    'H₂SO₄', 'CH₄', 'NaOH', 'HCl', 'Fe', 'Cu', 'Ag', 'Zn',
    'Na', 'Cl', 'H₂', 'NH₃', 'C₂H₅OH', 'KMnO₄',
    'ΔH', 'Kₛₚ', 'M₁V₁=M₂V₂', 'PV=nRT',
  ],
  mathematics: [
    'π', '∑', '∫', '√', '∞', 'sin', 'cos', 'tan', 'log', 'lim',
    'dx', 'dy', 'x²', 'x³', '½', '¼', 'f(x)', '≈', '≠', '≤',
    '≥', '±', '×', '÷', '∠', '⊥', '∥', '≡', '∝', '∈',
    '∀', '∃', 'd/dx', '∫dx', 'Σxᵢ', 'n!', 'C(n,r)', 'P(n,r)',
  ],
  biology: [
    'DNA', 'RNA', 'ATP', 'O₂', 'CO₂', 'H₂O', 'C₆H₁₂O₆',
    'A=T', 'G≡C', 'AUGC', 'tRNA', 'mRNA', 'pH 7.4',
    '₂n', 'N=N', 'Punnett', '×²', 'mitosis', 'meiosis',
  ],
  'computer-science': [
    '0', '1', '1010', 'AND', 'OR', 'XOR', 'NOT', 'if/else',
    'O(n)', 'log(n)', 'O(1)', 'O(n²)', 'byte', 'bit', '8-bit',
    '{ }', '< >', '!=', '==', '++', '--', 'n++', 'i=0',
    'while', 'for', 'return', 'null', 'true', 'false',
  ],
  'business-studies': [
    '$', '£', 'ROI', 'P&L', 'B2B', 'B2C', 'SWOT', 'KPI',
    'USP', 'CRM', 'PEST', '4Ps', 'SOP', 'MOQ', 'SKU',
  ],
  economics: [
    '€', '¥', 'GDP', 'CPI', 'Qd', 'Qs', 'MC', 'MR',
    'AC', 'TC', 'TR', 'AR', 'ΔQ', 'ΔP', 'E_d', 'MPC',
    'MPS', 'APC', 'APS', 'G=I', 'C+I+G', 'AD=AS',
  ],
  accounts: [
    'Dr', 'Cr', 'A=L+E', 'EBITDA', 'ROE', 'ROA',
    'P&L', 'BS', 'CF', 'GP', 'NP', 'EPS', 'PE',
    'Debit', 'Credit', 'T-Acct', 'Journal', 'Ledger',
  ],
};

// All symbols combined (for pages that show all subjects, e.g. home)
const allSymbols = Object.values(subjectSymbols).flat();

const COLORS = [
  'rgba(255, 255, 255, 0.42)',
  'rgba(255, 255, 255, 0.34)',
  'rgba(255, 255, 255, 0.28)',
  'rgba(245, 232, 255, 0.38)',
  'rgba(255, 255, 255, 0.50)',
];

export function FloatingSymbols({
  fixed = false,
  density = 'default',
  subject,
}: {
  fixed?: boolean;
  density?: 'default' | 'sparse';
  subject?: string;
}) {
  const containerRef = useRef<HTMLDivElement>(null);
  const symbolsRef = useRef<SymbolData[]>([]);
  const mouseRef = useRef({ x: -9999, y: -9999 });
  const animationRef = useRef<number>(0);

  // Pick the symbol pool: subject-specific or all
  const pool = subject && subjectSymbols[subject] ? subjectSymbols[subject] : allSymbols;

  const initSymbols = useCallback(() => {
    const container = containerRef.current;
    if (!container) return;
    const w = fixed ? window.innerWidth : container.offsetWidth;
    const h = fixed ? window.innerHeight : container.offsetHeight;
    const isMobile = w < 768;
    const count = density === 'sparse'
      ? (isMobile
        ? Math.min(16, Math.max(8, Math.floor((w * h) / 24000)))
        : Math.min(28, Math.max(16, Math.floor((w * h) / 16000))))
      : (isMobile
        ? Math.min(40, Math.max(20, Math.floor((w * h) / 12000)))
        : Math.min(80, Math.max(40, Math.floor((w * h) / 8000))));

    // Clear old DOM nodes
    container.innerHTML = '';

    symbolsRef.current = Array.from({ length: count }, (_, i) => {
      const span = document.createElement('span');
      const color = COLORS[i % COLORS.length];
      const size = 18 + Math.random() * 36;
      const opacity = 0.30 + Math.random() * 0.30;
      const rotation = Math.random() * 360;

      span.className = 'floating-symbol';
      span.style.position = 'absolute';
      span.style.fontSize = `${size}px`;
      span.style.setProperty('--symbol-opacity', String(opacity));
      span.style.setProperty('--symbol-start-opacity', String(opacity * 0.55));
      span.style.animationDelay = `${Math.min(i * 12, 720)}ms`;
      span.style.color = color;
      span.style.fontFamily = 'serif';
      span.style.fontWeight = '400';
      span.style.whiteSpace = 'nowrap';
      span.style.userSelect = 'none';
      span.style.willChange = 'transform';
      span.textContent = pool[Math.floor(Math.random() * pool.length)];
      container.appendChild(span);

      const vx = (Math.random() - 0.5) * 0.3;
      const vy = (Math.random() - 0.5) * 0.3;

      return {
        id: i,
        char: span.textContent || '',
        x: Math.random() * w,
        y: Math.random() * h,
        vx,
        vy,
        baseVx: vx,
        baseVy: vy,
        size,
        opacity,
        rotation,
        rotationSpeed: (Math.random() - 0.5) * 0.3,
        color,
        el: span,
      };
    });
  }, [pool, fixed, density]);

  useEffect(() => {
    initSymbols();

    const handleResize = () => initSymbols();
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    };
  }, [initSymbols]);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const handleMouseMove = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      mouseRef.current = { x: e.clientX - rect.left, y: e.clientY - rect.top };
    };

    const handleMouseLeave = () => {
      mouseRef.current = { x: -9999, y: -9999 };
    };

    // Listen on window since the container has pointerEvents: none
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseleave', handleMouseLeave);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseleave', handleMouseLeave);
    };
  }, []);

  useEffect(() => {
    const animate = () => {
      const container = containerRef.current;
      if (!container) {
        animationRef.current = requestAnimationFrame(animate);
        return;
      }

      const w = fixed ? window.innerWidth : container.offsetWidth;
      const h = fixed ? window.innerHeight : container.offsetHeight;
      const mouse = mouseRef.current;
      const mouseRadius = 100;

      for (const sym of symbolsRef.current) {
        // Mouse repulsion
        const dx = sym.x - mouse.x;
        const dy = sym.y - mouse.y;
        const dist = Math.sqrt(dx * dx + dy * dy);

        if (dist < mouseRadius && dist > 0) {
          const force = (mouseRadius - dist) / mouseRadius;
          sym.vx += (dx / dist) * force * 0.5;
          sym.vy += (dy / dist) * force * 0.5;
        }

        // Drift back to base velocity
        sym.vx += (sym.baseVx - sym.vx) * 0.01;
        sym.vy += (sym.baseVy - sym.vy) * 0.01;

        sym.x += sym.vx;
        sym.y += sym.vy;

        // Wrap around edges
        if (sym.x < -50) sym.x = w + 50;
        if (sym.x > w + 50) sym.x = -50;
        if (sym.y < -50) sym.y = h + 50;
        if (sym.y > h + 50) sym.y = -50;

        sym.rotation += sym.rotationSpeed;

        if (sym.el) {
          sym.el.style.transform = `translate(${sym.x}px, ${sym.y}px) rotate(${sym.rotation}deg)`;
        }
      }

      animationRef.current = requestAnimationFrame(animate);
    };

    animationRef.current = requestAnimationFrame(animate);

    return () => {
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    };
  }, [fixed]);

  return (
    <div
      ref={containerRef}
      className="floating-symbols-container"
      style={{
        position: 'absolute',
        inset: 0,
        overflow: 'hidden',
        pointerEvents: 'none',
        zIndex: 0,
      }}
    />
  );
}
