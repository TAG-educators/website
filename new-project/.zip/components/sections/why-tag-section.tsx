﻿'use client';

import { motion, useReducedMotion } from 'framer-motion';
import { whyItems } from '@/lib/content';
import { IconBlock } from './icon-block';
import { Ship, Waves } from 'lucide-react';
import { FloatingSymbols } from '@/components/sections/floating-symbols';

export function WhyTagSection() {
  const prefersReducedMotion = useReducedMotion();

  return (
    <section className="relative py-16 pb-8 md:py-28" data-header-theme="dark">
      <FloatingSymbols />
      <div className="absolute inset-0 bg-grid-pattern opacity-[0.04]" />
      <div className="absolute -right-32 top-0 h-96 w-96 rounded-full bg-ocean/15 blur-[120px]" />
      <div className="absolute -left-32 bottom-0 h-80 w-80 rounded-full bg-ocean-light/10 blur-[100px]" />

      {/* Decorative ship */}
      <motion.div
        initial={prefersReducedMotion ? undefined : { opacity: 0 }}
        animate={prefersReducedMotion ? undefined : { opacity: 0.06 }}
        transition={{ duration: 1.5 }}
        className="absolute right-10 top-1/2 -translate-y-1/2 hidden lg:block"
      >
        {!prefersReducedMotion && (
          <motion.div
            animate={{ y: [0, -12, 0], rotate: [-2, 1, -2] }}
            transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut' }}
          >
            <Ship className="h-64 w-64 text-white" strokeWidth={0.5} />
          </motion.div>
        )}
        {prefersReducedMotion && <Ship className="h-64 w-64 text-white" strokeWidth={0.5} />}
      </motion.div>

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={prefersReducedMotion ? undefined : { opacity: 0, y: 20 }}
          whileInView={prefersReducedMotion ? undefined : { opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.1, margin: '0px 0px -40px 0px' }}
          transition={{ duration: 0.6 }}
          className="max-w-2xl"
        >
          <p className="text-sm font-semibold uppercase tracking-[0.15em] text-ocean-light">
            The TAG Advantage
          </p>
          <h2 className="mt-4 font-display text-3xl font-bold tracking-tight text-white sm:text-4xl lg:text-5xl text-balance">
            Why Learn With TAG Educators?
          </h2>
          <p className="mt-5 text-lg leading-relaxed text-white/70 text-pretty">
            We are not a tutoring marketplace. We are a focused team of subject specialists who
            have been through these exact exams   and know how to get students through them too.
          </p>
        </motion.div>

        <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {whyItems.map((item) => (
            <IconBlock
              key={item.title}
              icon={item.icon}
              title={item.title}
              description={item.description}
              variant="dark"
            />
          ))}
        </div>
      </div>
    </section>
  );
}
